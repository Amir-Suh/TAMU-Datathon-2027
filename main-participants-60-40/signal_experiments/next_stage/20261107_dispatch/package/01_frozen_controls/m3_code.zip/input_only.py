import csv
import numpy as np
from models.common.data import MISSING, PAYOUT_INDEX, TYPES, Split

def input_only(data, split_name):
    """Read query/history files only, never validation labels/targets/reference."""
    folder = data / split_name
    with (folder / 'queries.csv').open(newline='') as stream:
        queries = list(csv.DictReader(stream))
    cutoff = np.array([int(q['cutoff']) for q in queries])
    matrix = np.full((len(queries), int(cutoff.max()) + 1), MISSING, dtype=np.int8)
    index = {(q['episode_id'], q['machine_id']): i for i, q in enumerate(queries)}
    with (folder / 'history.csv').open(newline='') as stream:
        for row in csv.DictReader(stream):
            i = index[(row['episode_id'], row['machine_id'])]
            t = int(row['tick'])
            if not 0 <= t < cutoff[i] or matrix[i, t] != MISSING:
                raise ValueError('Invalid or duplicated pre-cutoff observation')
            matrix[i, t] = PAYOUT_INDEX[int(row['payout'])]
    return Split(split_name, [q['query_id'] for q in queries],
                 np.array([q['episode_id'] for q in queries]), [q['machine_id'] for q in queries],
                 np.array([TYPES.index(q['machine_type']) for q in queries]),
                 np.array([int(q['signal']) for q in queries]), cutoff, matrix)

