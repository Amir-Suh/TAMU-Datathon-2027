# House Edge main m3

Season `5fffdc4d0c700bbf61c3f911`. Frozen main forecast SHA-256 `7e60f59ed821e85de73094d62e13da18020d4e4cb5f5ba508595dd83491a257c`.

Python 3.13. Install the exact versions in `requirements.txt` before running offline.
Run from `/submission` with the released round mounted at `/data` and writable output
at `/output`.

```sh
python -B predict.py --model m3 --data /data --out /output/submission.csv
```

The command reads test query IDs and pre-cutoff histories and writes
`/output/submission.csv`. All learned state is under `weights/`.
The frozen M3 win and conditional payout heads were fitted using released main training histories and train cutoff outcomes.
