# House Edge main hybrid

Season `5fffdc4d0c700bbf61c3f911`. Frozen main forecast SHA-256 `ce389ffa0eaede28f55ad8df70ccbdcec8c251f214416792d6d830130a68c74a`.

Python 3.13. Install the exact versions in `requirements.txt` before running offline.
Run from `/submission` with the released round mounted at `/data` and writable output
at `/output`.

```sh
python -B predict.py --model hybrid --data /data --out /output/submission.csv
```

The command reads test query IDs and pre-cutoff histories and writes
`/output/submission.csv`. All learned state is under `weights/`.
The win head is frozen M3 with a train-history 00/11 match-cell contrast. The positive payout mix conditions an equal mixture of the 31-leaf LightGBM forecast and the mean of factored GRU seeds 1, 2, and 3. The archived tree and GRUs were fitted transductively on released pre-cutoff histories. The GRUs also used released train cutoff outcomes. Tree early stopping used held train episodes. The branch source is bbff7379e57984eb623588273ed1c958bb8b4f47.
