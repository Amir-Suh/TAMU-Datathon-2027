"""Dense, deterministic round data. Cached inputs never contain validation answers."""
from dataclasses import dataclass, replace, fields
import csv
import hashlib
import json
from pathlib import Path
import numpy as np

PAYOUTS = (0, 1, 2, 5, 20)
_TYPES = {'steady': 0, 'balanced': 1, 'jackpot': 2}
_CODES = {str(p): i for i, p in enumerate(PAYOUTS)}

@dataclass
class Split:
    name: str
    ids: list[str]
    y: np.ndarray
    mtype: np.ndarray
    signal: np.ndarray
    cutoff: np.ndarray
    n_obs: np.ndarray
    query_ids: np.ndarray
    label: np.ndarray | None = None
    condition: np.ndarray | None = None
    target: np.ndarray | None = None
    reference: np.ndarray | None = None

@dataclass
class Round:
    name: str
    root: Path
    splits: dict[str, Split]
    max_points: float

def _rows(path):
    with Path(path).open(newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))

def _read_split(root, name):
    qs = _rows(root / name / 'queries.csv')
    ids = sorted({r['episode_id'] for r in qs})
    ei = {v: i for i, v in enumerate(ids)}
    machines = {ep: sorted(r['machine_id'] for r in qs if r['episode_id'] == ep) for ep in ids}
    if any(len(ms) != 8 or len(set(ms)) != 8 for ms in machines.values()):
        raise ValueError('Expected eight unique machines per episode')
    mi = {(ep, m): j for ep, ms in machines.items() for j, m in enumerate(ms)}
    shape = (len(ids), 8)
    y = np.full((*shape, 256), -1, dtype=np.int8)
    mt, sig = np.empty(shape, np.int8), np.empty(shape, np.int8)
    cutoff = np.full(len(ids), -1, np.int16)
    qids = np.empty(shape, object)
    for r in qs:
        e, m = ei[r['episode_id']], mi[r['episode_id'], r['machine_id']]
        c = int(r['cutoff'])
        if not 0 <= c <= 256 or cutoff[e] not in (-1, c):
            raise ValueError('Invalid/inconsistent cutoff')
        cutoff[e] = c
        mt[e, m], sig[e, m] = _TYPES[r['machine_type']], int(r['signal'])
        qids[e, m] = r['query_id']
    for r in _rows(root / name / 'history.csv'):
        e, m = ei[r['episode_id']], mi[r['episode_id'], r['machine_id']]
        t = int(r['tick'])
        if not 0 <= t < cutoff[e] or y[e, m, t] != -1:
            raise ValueError('Future/duplicate/out of range history')
        y[e, m, t] = _CODES[r['payout']]
    split = Split(name, ids, y, mt, sig, cutoff, (y >= 0).sum(-1).astype(np.int16), qids)
    return split

