# House Edge main W1a + P0

Season `5fffdc4d0c700bbf61c3f911`. Frozen main forecast SHA-256 `c7c34efd491648b5a7cf97bfa04df090427fc528dde31a28800211575a856b8b`.

Python 3.13. Install the exact versions in `requirements.txt` before running offline.
Run from `/submission` with the released round mounted at `/data` and writable output
at `/output`.

```sh
python -B predict.py --model w1a_p0 --data /data --out /output/submission.csv
```

The command reads test query IDs and pre-cutoff histories and writes
`/output/submission.csv`. All learned state is under `weights/`.
The frozen M3 posterior and the W1a pooled 00/11 and 01/10 contrasts supply the win head. W1a contrasts and smoothing were estimated using released main training history and train-only grouped pseudo-cutoffs. An equal mixture of the 31-leaf LightGBM forecast and the mean of factored GRU seeds 1, 2, and 3 supplies the conditional 1x probability and combined tail mass. The P0 type-specific 2x, 5x, and 20x shares come from released pre-cutoff training payout counts. The archived tree and GRUs were fitted transductively on released pre-cutoff histories. GRUs also used released train cutoff outcomes. Tree early stopping used held train episodes.
