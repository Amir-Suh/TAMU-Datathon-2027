from dataclasses import dataclass
import numpy as np
from models.common.components import combine
from models.common.data import MISSING, Split
from models.m3_lag_pair_flip.model import FlipLagPairModel, _lagged

GLOBAL_PRIOR = 200.0
LOCAL_PRIOR = 20.0
MIN_HISTORY_PSEUDO = 8.0


@dataclass
class MatchCells:
    n00: np.ndarray
    wins00: np.ndarray
    n11: np.ndarray
    wins11: np.ndarray
    current: np.ndarray  # -1 unknown, 0 = 00, 1 = 11, 2 = differ

    def evidence(self) -> tuple[np.ndarray, np.ndarray]:
        n = self.n00 + self.n11
        effective = self.n00 * self.n11 / np.maximum(n, 1)
        observed = (self.wins11 / np.maximum(self.n11, 1)
                    - self.wins00 / np.maximum(self.n00, 1))
        return effective, observed


def win_history(split: Split) -> np.ndarray:
    observed = split.X != MISSING
    if np.any(observed & (np.arange(split.X.shape[1]) >= split.cutoff[:, None])):
        raise ValueError("Found history at or after cutoff.")
    return np.where(observed, split.X > 0, MISSING).astype(np.int8)


def match_cells(w: np.ndarray, cutoff: np.ndarray, pair: tuple[int, int],
                tau_grid: np.ndarray) -> MatchCells:
    a, b = pair
    lag_a, lag_b = _lagged(w, a), _lagged(w, b)
    # Prefix counts at tick g are counts for t < g. Subtraction leaves
    # observed outcomes at t >= g, all of which precede the query cutoff.
    positions = np.r_[0, np.minimum(tau_grid, w.shape[1])]
    won = w == 1
    suffix = []
    for child in (0, 1):
        in_cell = (w >= 0) & (lag_a == child) & (lag_b == child)
        for counted in (in_cell, in_cell & won):
            prefix = np.column_stack([np.zeros(w.shape[0]), counted.cumsum(axis=1)])
            suffix.append(prefix[:, -1:] - prefix[:, positions])
    rows = np.arange(w.shape[0])
    current_a, current_b = lag_a[rows, cutoff], lag_b[rows, cutoff]
    current = np.where(
        (current_a == MISSING) | (current_b == MISSING), MISSING,
        np.where(current_a == current_b, current_a, 2),
    )
    return MatchCells(*suffix, current)


def child_forecasts(parent: np.ndarray, cells: MatchCells,
                    prior: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    effective, observed = cells.evidence()
    n = cells.n00 + cells.n11
    contrast = (LOCAL_PRIOR * prior[None, :, None] + (effective * observed)[:, None, :])
    contrast /= (LOCAL_PRIOR + effective)[:, None, :]
    contrast *= (n / (n + MIN_HISTORY_PSEUDO))[:, None, :]

    # Keep the expected child probabilities centered on M3's match parent
    # under the empirical subtype frequencies (one pseudocount per child).
    frac11 = ((cells.n11 + 1) / (n + 2))[:, None, :]
    frac00 = 1 - frac11
    lower = np.maximum(-(1 - parent) / frac11, -parent / frac00)
    upper = np.minimum(parent / frac11, (1 - parent) / frac00)
    contrast = np.clip(contrast, lower, upper)
    return parent - frac11 * contrast, parent + frac00 * contrast


def predict(model: FlipLagPairModel, split: Split, prior: np.ndarray) -> dict:
    w = win_history(split)
    inference = model._infer(split)
    posterior = inference["ind"]["post"]
    top = posterior.sum(axis=(2, 3)).argmax(axis=1)
    category = np.full(split.n, MISSING)
    delta = np.zeros(split.n)
    match_mass = np.zeros(split.n)
    max_center_error = 0.0
    for pi, pair in enumerate(model.pairs):
        cells = match_cells(w, split.cutoff, pair, model.tau_grid)
        category[top == pi] = cells.current[top == pi]
        parent = inference["core"]["pred"][:, pi]
        match = (cells.current == 0) | (cells.current == 1)
        if not np.any(match):
            continue
        child00, child11 = child_forecasts(parent, cells, prior)
        current = np.where((cells.current == 0)[:, None, None], child00, child11)
        delta[match] += (posterior[match, pi] * (current[match] - parent[match])).sum(axis=(1, 2))
        match_mass[match] += posterior[match, pi].sum(axis=(1, 2))
        frac11 = ((cells.n11 + 1) / (cells.n00 + cells.n11 + 2))[:, None, :]
        center_error = np.abs((1 - frac11) * child00 + frac11 * child11 - parent)
        max_center_error = max(max_center_error, float(center_error.max()))
    frozen_win = inference["p_win"]
    if np.any(delta[match_mass == 0] != 0):
        raise ValueError("Win probability changed without a matching hypothesis.")
    size = model.size.predict(split)
    return {
        "frozen": combine(frozen_win, size),
        "candidate": combine(frozen_win + delta, size),
        "top_pair_category": category,
        "match_posterior_mass": match_mass,
        "win_delta": delta,
        "max_center_error": max_center_error,
    }


