import numpy as np
import match_split as w0
from models.common.data import MISSING
from models.m3_lag_pair_flip.model import _lagged

CELLS = ((0, 3), (1, 2))


def ordered_counts(w, cutoff, pair, tau_grid):
    """Post-flip complete triples in cell order 00, 01, 10, 11."""
    a, b = pair
    lag_a, lag_b = _lagged(w, a), _lagged(w, b)
    available = (w >= 0) & (lag_a >= 0) & (lag_b >= 0)
    codes = 2 * lag_a + lag_b
    grid = np.r_[0, np.minimum(tau_grid, w.shape[1])]
    suffixes = []
    for cell in range(4):
        valid = available & (codes == cell)
        counts = []
        for mask in (valid, valid & (w == 1)):
            prefix = np.column_stack((np.zeros(w.shape[0], dtype=int), mask.cumsum(axis=1)))
            counts.append(prefix[:, -1:] - prefix[:, grid])
        suffixes.append(counts)
    n, k = np.array(suffixes).transpose(1, 2, 3, 0)
    rows = np.arange(len(cutoff))
    current = np.where((lag_a[rows, cutoff] >= 0) & (lag_b[rows, cutoff] >= 0),
                       codes[rows, cutoff], MISSING)
    return n, k, current


def cell_evidence(n, k, children):
    left, right = children
    total = n[..., left] + n[..., right]
    effective = n[..., left] * n[..., right] / np.maximum(total, 1)
    observed = k[..., right] / np.maximum(n[..., right], 1) - k[..., left] / np.maximum(n[..., left], 1)
    fraction_right = (n[..., right] + 1) / (total + 2)
    return total, effective, observed, fraction_right


def centered_children(parent, fraction_right, contrast):
    fraction_left = 1 - fraction_right
    lower = np.maximum(-(1 - parent) / fraction_right, -parent / fraction_left)
    upper = np.minimum(parent / fraction_right, (1 - parent) / fraction_left)
    contrast = np.clip(contrast, lower, upper)
    return parent - fraction_right * contrast, parent + fraction_left * contrast


def forecast(model, split, fit, variants):
    """Evaluate predeclared arms with one shared upstream posterior."""
    w = w0.win_history(split)
    inference = model._infer(split)
    posterior = inference["ind"]["post"]
    pair_posterior = posterior.sum(axis=(2, 3))
    top = pair_posterior.argmax(axis=1)
    delta = {name: np.zeros(split.n) for name in variants}
    baseline_delta = np.zeros(split.n)
    top_context = np.full(split.n, MISSING)
    top_support = np.zeros((split.n, 4))
    weighted_counts = np.zeros((split.n, 4))
    eligible_mass = np.zeros((split.n, 4))
    max_center_error = 0.0
    typed = fit.typed() if any(arm == "W1c" for arm, _ in variants.values()) else None
    for i, pair in enumerate(model.pairs):
        n, k, current = ordered_counts(w, split.cutoff, pair, model.tau_grid)
        top_context[top == i] = current[top == i]
        top_support[top == i] = n[top == i, 0]
        parent = inference["core"]["pred"][:, i]
        post = posterior[:, i]
        for group, children in enumerate(CELLS):
            use = np.isin(current, children)
            if not np.any(use):
                continue
            total, effective, observed, frac_right = cell_evidence(n[use], k[use], children)
            parent_group, post_group = parent[use], post[use]
            frac_right = frac_right[:, None, :]
            local = (effective * observed)[:, None, :]
            support = (total / (total + w0.MIN_HISTORY_PSEUDO))[:, None, :]
            supported = effective[:, None, :] > 0
            right = (current[use] == children[1])[:, None, None]
            for cell in children:
                at_cell = use & (current == cell)
                weighted_counts[at_cell, cell] += (post[at_cell] * n[at_cell, None, :, cell]).sum(axis=(1, 2))
                eligible_mass[at_cell, cell] += (post_group[current[use] == cell]
                                                * supported[current[use] == cell]).sum(axis=(1, 2))

            def correction(contrast):
                nonlocal max_center_error
                left_p, right_p = centered_children(parent_group, frac_right, contrast)
                centered = (1 - frac_right) * left_p + frac_right * right_p
                max_center_error = max(max_center_error, float(np.abs(centered - parent_group).max()))
                return (post_group * (np.where(right, right_p, left_p) - parent_group)).sum(axis=(1, 2))

            pooled = fit.pooled[group, None, :, None]
            if group == 0:
                # Preserve the published W0 match refinement, including its one-child fallback.
                base_contrast = (local + w0.LOCAL_PRIOR * pooled) / (effective[:, None, :] + w0.LOCAL_PRIOR) * support
                base_change = correction(base_contrast)
                baseline_delta[use] += base_change
            for name, (arm, strength) in variants.items():
                if group == 0 and arm == "W1a":
                    delta[name][use] += base_change
                    continue
                prior = pooled
                if arm == "W1b":
                    prior = fit.pair[i, group, None, :, None]
                if arm == "W1c":
                    prior = typed[split.machine_type[use], i, group, :, None]
                weight = strength / (effective[:, None, :] + strength) * support
                if group == 0:
                    contrast = base_contrast + np.where(supported, weight * (prior - pooled), 0.0)
                else:
                    contrast = np.where(supported, local / (effective[:, None, :] + strength) * support
                                        + weight * prior, 0.0)
                delta[name][use] += correction(contrast)
    frozen = inference["p_win"]
    wins = {"M3": frozen, "W0": frozen + baseline_delta}
    wins.update({name: frozen + change for name, change in delta.items()})
    if any(np.any(~np.isfinite(p) | (p < 0) | (p > 1)) for p in wins.values()):
        raise ValueError("Invalid win probability.")
    if not np.allclose(posterior.sum(axis=(1, 2, 3)) + inference["ind"]["post0"], 1, atol=1e-12, rtol=0):
        raise ValueError("Frozen posterior failed normalization.")
    return wins, {"top_pair": top, "top_context": top_context, "top_no_flip_cell_counts": top_support,
                  "posterior_weighted_current_cell_count": weighted_counts,
                  "supported_posterior_mass": eligible_mass,
                  "max_center_error": max_center_error}


