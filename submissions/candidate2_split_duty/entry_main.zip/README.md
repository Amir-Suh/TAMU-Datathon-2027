# House Edge entry

Round: main; season: 5fffdc4d0c700bbf61c3f911. Team: supply in submission form.
Python 3.13; CPU only; one inference thread; seeds in config.json.
Dependencies: numpy==2.5.4, scipy==1.18.1.

Run from this folder: `python predict.py --data /data --out /output/submission.csv`.
The data and submission folder can be read-only. Only the requested output and /tmp are written.
Models and settings are in models/, config.json and blend.json. No main-round data is reused in adaptation.
Saved models were fitted with tdx.run in the mode recorded in config.json; the no-arm skeleton fits pooled_recent on train history and labels only. Machine-specific inference uses released test history. The emergency fallback fits pooled_recent on train.
Forecast SHA-256: d2a277fb64e6c894a9271e0a67b834b7ecad1367e0536db54d772d135921a11d.
Training/refit: `python -m tdx.pipeline --round main --data <public>` in the project checkout.
Organizer limits: 2 CPU cores, 16 GiB RAM, 30 minutes; no GPU or network.
Validate the separate CSV with the released kit checker and run the project fresh-folder repro_check.sh.
Fallback use is printed to stderr and /tmp/predict_fallback.json; never upload a fallback run.
