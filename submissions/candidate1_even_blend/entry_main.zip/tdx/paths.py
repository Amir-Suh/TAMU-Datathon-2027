import os
from pathlib import Path
ROOT = Path("/tmp/tdx-entry-cache")
KIT = Path(__file__).resolve().parents[1]
def data_root(data=None, round_name="main"):
    if data is None:
        raise ValueError("Explicit --data is required")
    return Path(data).resolve()
