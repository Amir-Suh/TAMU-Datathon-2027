# House Edge Main entry | Candidate 3b clean refit

Round Main, season 5fffdc4d0c700bbf61c3f911. Supply team in the submission form.

Run from the extracted ZIP root with Python 3.13. Install the exact pins in
`requirements.txt` before running offline.

```sh
python predict.py --data /data --out /output/submission.csv
```

The runner uses one inference thread on CPU. It loads 12 frozen GRU checkpoints
and eight frozen convolution + ALiBi transformer checkpoints. It fits the M3
priors on the released train split. M3's historical win and payout tuning
uses neutral signal for simulated earlier queries. Forecasts use released
test history and the signal recorded at each actual query cutoff.

The locked factored blend in `blend.json` combines win probabilities and
conditional payout sizes separately. The weights were fit on historical tails
from 72 public validation episodes using train-only calibration models and
neutral signal at every simulated earlier cutoff. The remaining 24 episodes
were reserved for comparison at their actual query cutoffs. The neural
checkpoints used for the final forecasts are the original Candidate 3b
checkpoints. Their dev fit used released histories before the official cutoffs.

Forecast SHA-256 `484099882d409ae92cdf62e96ce6a23e3aa5c69f254199e2f63e8dbec32a27a3`

The package and data may be mounted read-only. Inference writes the CSV to
the requested output path. If primary inference fails, the runner logs the
fallback to stderr and /tmp/predict_fallback.json.
